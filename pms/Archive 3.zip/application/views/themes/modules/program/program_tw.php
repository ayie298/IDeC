<table width='100%' cellpadding='4' cellspacing='2' border='0' style="border: 1px solid rgb(204,209,205);">
	<tr>
		<td width='20%'>Metric</td>
		<td width='20%'>Value</td>
		<td width='40%'>Target Detail</td>
	</tr>
	<tr>
		<td>
			<select size="1" class="input" name="Quantity" id="Quantity" style="width:100px;margin: 0;">
				<option>Quantity</option>
			</select>
		</td>
		<td><input type="text" size="20" name="Number" id="Number" placeholder="Name" style="margin: 0;height: 30px;width:150px"/></td>
		<td><input type="text" size="20" name="Number" id="Number" placeholder="Name" style="margin: 0;height: 30px;width:400px"/></td>
	</tr>
	<tr>
		<td>
			<select size="1" class="input" name="Quantity" id="Quantity" style="width:100px;margin: 0;">
				<option>Date</option>
			</select>
		</td>
		<td><input type="text" size="20" name="Number" id="Number" placeholder="Name" style="margin: 0;height: 30px;width:150px"/></td>
		<td><input type="text" size="20" name="Number" id="Number" placeholder="Name" style="margin: 0;height: 30px;width:400px"/></td>
	</tr>
</table>
<br>
<button class='btn' id='btn_save' type='button'>ADD</button>