<div class="widget red">
	 <div class="widget-title">
		<h4><i class=" icon-key"></i>Profile</h4>
	 </div>
	 <div class="widget-body form">
		<div style="float:left;position:relative;font-weight:bold;padding-top:2px;padding-left:5px;width:170px"><?php echo $user->username ?></div>
		<div style="float:left;position:relative;padding-left:5px;"><?php echo ucfirst($user->level_name)?></div>
		<div id="clear">&nbsp;</div>
		<div id="clear">&nbsp;</div>
		<div id="clear">&nbsp;</div>
		<div style="float:left;position:relative;font-weight:bold"><?php echo anchor(base_url()."idec/edit_profile"," My Profile ","class=link2")?></div>
		<div style="float:left;position:relative;padding-left:5px;">&nbsp;</div>
		<div style="float:left;position:relative;font-weight:bold"><?php echo anchor(base_url()."idec/notification"," Notification ","class=link2")?></div>
		<div id="clear">&nbsp;</div>
		<div style="float:left;position:relative;font-weight:bold;"><?php echo anchor(base_url()."idec/logout"," Logout ","class=link2")?></div>
		<div id="clear">&nbsp;</div>
	 </div>
 </div>