<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Update extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		
		$this->load->library('files');
		$this->load->library('user');

		$this->load->model('modules/users/user_model');
		$this->load->model('modules/employee/employee_model');
		$this->load->model('modules/program/program_model');
		$this->load->model('modules/project/project_model');
		$this->load->model('modules/researcher/researcher_model');
		$this->load->model('idec_model');
	}

	public function index($id = null)
	{
		if($_POST) {
			$po   = $this->employee_model->find(array('nik' => $this->input->post('po')));
			$pm   = $this->employee_model->find(array('nik' => $this->input->post('pm')));
			$auto = $this->program_model->getAutoIncrement();

			$validation = array(
				array(
					'field' => 'budget',
					'label' => 'Budget',
					'rules' => 'numeric|required'
				)
			);

			$data = array(
				'name'		 				=> $this->input->post('name'),
				'description'				=> $this->input->post('desc'),
				'output'					=> $this->input->post('output'),
				'user'						=> $this->input->post('user'),
				'start_date'				=> $this->input->post('date'),
				'end_date'					=> $this->input->post('date_end'),
				'quartal'					=> $this->input->post('quartal'),
				'primary_program'			=> $this->input->post('prime'),
				'deliverable'				=> $this->input->post('deliver'),
				'KPI'						=> $this->input->post('kpi'),
				'implementation_strategy'	=> $this->input->post('implement'),
				'strategic_initative'		=> $this->input->post('strategic'),
				'id_organization_item'		=> $this->input->post('unit'),
				'id_employee_po'			=> $po->id_employee,
				'id_employee_pm'			=> $pm->id_employee,
				'id_annual_data'			=> 0,
				'show_on_review'			=> 0,
				'id_mas_project_status'		=> $this->input->post('status'),
				'id_mas_research_type'		=> $this->input->post('type'),
				'budget'					=> $this->input->post('budget')
			);
			
			$this->form_validation->set_rules($validation);

			if($this->form_validation->run() === TRUE) {
				if(!empty($id) && $id !== 'index') {
					$this->db->where('id_program', $this->input->post('id'));
					$this->db->update('program', $data);

					$msg 	= 'updated';
					$idRed	= $this->input->post('id');

				} else {
					$data['id_program'] = $auto;

					$this->db->insert('program', $data);

					$msg 	= 'added';
					$idRed	= $auto;
				}

				$this->session->set_flashdata('notice', 'Program has been ' . $msg);

				redirect('program/update/' . md5($idRed));

			} else {
				$this->session->set_flashdata('notice', validation_errors());

				redirect('program/update/');
			}
		}

		$data['program']		= array();

		if(!empty($id) && $id !== 'index') {
			$program	= $this->program_model->find(array('md5(id_program)' => $id));
			$po   		= $this->employee_model->find(array('id_employee' => $program->id_employee_po));
			$pm   		= $this->employee_model->find(array('id_employee' => $program->id_employee_pm));

			$data['program'] = $program;
			$data['pm']		 = !empty($program->id_employee_pm) ? $pm->nik : NULL;
			$data['po']		 = !empty($program->id_employee_po) ? $po->nik : NULL;
		}

		$data['organization'] 	= $this->employee_model->organization(array('level' => 'unit'));
		$data['status']			= $this->idec_model->findMaster('mas_project_status');
		$data['resType']		= $this->idec_model->findMaster('mas_research_type');
		$data['title']			= 'Add';

		$this->template->write_view('content', MODULE_VIEW_PATH.'program/program_new', $data);
		$this->template->render();
	}

	public function _remap($params = null)
	{
		$this->index($params);
	}
}