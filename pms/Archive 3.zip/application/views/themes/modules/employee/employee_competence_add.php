<div style="width:99%;background-color:#DDDDDD;-moz-border-radius:5px;border-radius:5px;padding:2px;border:3px solid #ebebeb;">
    <?php echo form_open() ?>
    <input type="hidden" name="id" value="<?php echo $id_employee ?>" />
    <table width='100%' cellpadding='4' cellspacing='2' border='0' style="border: 1px solid rgb(204,209,205);background: rgb(244,244,244);">
    <tr>
        <td colspan="3" style="font-size:20px"><?php echo $title ?></td>
    </tr>
    <tr id="td_proses" height="30">
        <td colspan="3" align="right">
			<input type="submit" name="submit" class='btn' id='btn_save' value="SAVE" />
		</td>
    </tr>
    <tr>
        <td width='18%'>Name</td>
        <td width='1%'>:</td>
        <td class="white">
            <select name="competence">
            <option>Choose</option>
            <?php foreach($competence as $comp) : ?>
                <option value="<?php echo $comp->id_mas_competence ?>"><?php echo $comp->name ?></option>
            <?php endforeach ?>
        </td>
    </tr>
    </table>
    </form>
</div>
