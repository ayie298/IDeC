<script type="text/javascript">
    $(document).ready(function(){
        $("#tanggal1").jqxDateTimeInput({ width: '140px', height: '30px', formatString: 'yyyy-MM-dd', theme: theme});
	});
</script>
<div style="width:99%;background-color:#DDDDDD;-moz-border-radius:5px;border-radius:5px;padding:2px;border:3px solid #ebebeb;">
	<?php echo form_open() ?>
	<input type="hidden" value="<?php echo $id_employee ?>" name="id" />
    <table width='100%' cellpadding='4' cellspacing='2' border='0' style="border: 1px solid rgb(204,209,205);background: rgb(244,244,244);">
    <tr>
        <td colspan="3" style="font-size:20px">Add / Edit Education</td>
    </tr>
    <tr id="td_proses" height="30">
        <td colspan="3" align="right">
			<input type="submit" name="submit" value="Save" class='btn' id='btn_save' />
		</td>
    </tr>
    <tr>
        <td width='18%'>Degre</td>
        <td width='1%'>:</td>
        <td class="white">
			<select size="1" class="input" name="degree" id="Degre" style="width: 300px;margin: 0;">
				<option>-</option>
				<option value="SD">SD</option>
				<option value="SMP">SMP</option>
				<option value="SMA">SMA</option>
				<option value="S1">S1</option>
				<option value="S2">S2</option>
				<option value="S3">S3</option>
			</select>
		</td>
    </tr>
    <tr>
        <td width='18%'>Institute</td>
        <td width='1%'>:</td>
        <td class="white"><input type="text" size="40" name="institute" id="Institute" placeholder="Institute" style="margin: 0;height: 30px;width:200px"/></td>
    </tr>
    <tr>
        <td width='18%'>Major</td>
        <td width='1%'>:</td>
        <td class="white">
			<select size="1" class="input" name="major" id="Category" style="width: 300px;margin: 0;">
				<option>-</option>
				<option value="Telekomunikasi">Telekomunikasi</option>
				<option value="Teknik">Teknik</option>
			</select>
		</td>
    </tr>
    <tr>
        <td width='18%'>Start Year</td>
        <td width='1%'>:</td>
        <td class="white">
			<select size="1" class="input" name="start_year" id="Start" style="width: 100px;margin: 0;">
				<option>-</option>
				<option>2010</option>
				<option>2011</option>
				<option>2012</option>
				<option>2013</option>
				<option>2014</option>
			</select>
		</td>
    </tr>
    <tr>
        <td width='18%'>End Year</td>
        <td width='1%'>:</td>
        <td class="white">
			<select size="1" class="input" name="end_year" id="Start" style="width: 100px;margin: 0;">
				<option>-</option>
				<option>2010</option>
				<option>2011</option>
				<option>2012</option>
				<option>2013</option>
				<option>2014</option>
			</select>
		</td>
    </tr>
    </table>
	</form>
</div>
