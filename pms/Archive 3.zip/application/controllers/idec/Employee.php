<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Employee extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		
		$this->load->library('files');

		$this->load->model('modules/users/user_model');
		$this->load->model('modules/employee/employee_model');
		$this->load->model('idec_model');
	}

	public function index()
	{
		$data = array();

		if($this->user->row()->level_name == "researcher"){
			$this->employee_detail();
		}else{
			$this->template->write_view('content', MODULE_VIEW_PATH.'employee/employee', $data);
		}

		$this->template->render();
	}

	public function edit($id = ""){
		if($_POST) {
			$data['nik']  				  	  = $this->input->post('nik');
			$data['name'] 				  	  = $this->input->post('name');
			$data['gender']				  	  = $this->input->post('gender');
			$data['id_mas_bp'] 			  	  = $this->input->post('bp');
			$data['id_organization_item'] 	  = $this->input->post('unit');
			$data['id_mas_employee_position'] = $this->input->post('position');

			$upload = $this->files->uploads('userfile', 'doc|docx|pdf', 'cv/');

			if(!empty($upload['error']) || $upload['error'] == 1) {
				$this->session->set_flashdata('notice', $upload['message']);

				redirect('idec/employee/edit/' . $id);

				return FALSE;
			}

			$data['cv_document'] = $upload['filename'];

			if(empty($id)) {
				$data['id_employee'] = sizeof($this->employee_model->findAll())+1;
				$data['id_user']	 = $this->user->row()->id_user;
			}

			$return = $this->employee_model->update($id, $data);

			if(empty($id)) {
				$id = md5($data['id_employee']);
			}

			if($return) {
				$this->session->set_flashdata('notice', 'Data saved');

				redirect('idec/employee/edit/' . $id);
			}
		}

		$data['employee'] 	  = $this->employee_model->find(array('md5(id_employee)' => $id));
		$data['bps'] 	  	  = $this->employee_model->getBP();
		$data['position'] 	  = $this->employee_model->position();
		$data['organization'] = $this->employee_model->organization(array('level' => 'unit'));
		$data['title'] 		  = $this->employee_model->title();
		$data['competence']   = $this->load->view(MODULE_VIEW_PATH.'employee/employee_competence', $data, TRUE);
		$data['training']     = $this->load->view(MODULE_VIEW_PATH.'employee/employee_training', $data, TRUE);
		$data['education']    = $this->load->view(MODULE_VIEW_PATH.'employee/employee_education', $data, TRUE);
		$data['certificate']  = $this->load->view(MODULE_VIEW_PATH.'employee/employee_certificate', $data, TRUE);

		if(empty($id)) {
			$this->template->write_view('content', MODULE_VIEW_PATH.'employee/employee_add', $data);	
		} else {
			$this->template->write_view('content', MODULE_VIEW_PATH.'employee/employee_edit', $data);
		}

		$this->template->render();
	}

	public function delete($id = "")
	{
		$this->db->where('md5(id_employee)', $id);

		$this->db->delete('employee');

		$this->session->set_flashdata('notice', 'Data deleted');

		redirect('idec/employee');
	}

	public function detail($id)
	{
		$data['employee'] = $this->employee_model->find(array('md5(id_employee)' => $id));
		$data['competence']   = $this->load->view(MODULE_VIEW_PATH.'employee/employee_competence_detail', $data, TRUE);
		$data['training']     = $this->load->view(MODULE_VIEW_PATH.'employee/employee_training_detail', $data, TRUE);
		$data['education']    = $this->load->view(MODULE_VIEW_PATH.'employee/employee_education_detail', $data, TRUE);
		$data['certificate']  = $this->load->view(MODULE_VIEW_PATH.'employee/employee_certificate_detail', $data, TRUE);

		$this->template->write_view('content', MODULE_VIEW_PATH.'employee/employee_detail', $data);
		$this->template->render();
	}

	public function json()
	{
		$data = array();
		$employes = $this->employee_model->findAll();

		foreach($employes as $employee) {
			$data[] = array(
				'id'   	=> md5($employee->id_employee),
				'nik'  	=> $employee->nik,
				'nama' 	=> $employee->name,
				'bp'   	=> 'I',
				'posisi'=> $employee->position,
				'unit'	=> $employee->org_name,
			);
		}

		$json = array(
			'TotalRows' => sizeof($data),
			'Rows' => $data
		);

		echo json_encode(array($json));
	}

	public function competence()
	{
		$data = array();
		$employes = $this->employee_model->competence(array('md5(id_employee)' => $this->input->get('id')));

		foreach($employes as $employee) {
			$data[] = array(
				'id'   			=> $employee->id_competence_employee,
				'id_employee'	=> $employee->id_employee,
				'name'  		=> $employee->name,
				'description' 	=> $employee->description
			);
		}

		$json = array(
			'TotalRows' => !empty($data) ? sizeof($data) : 0,
			'Rows' => $data
		);

		echo json_encode(array($json));
	}

	public function certificate()
	{
		$data = array();
		$employes = $this->employee_model->certificate(array('md5(id_employee)' => $this->input->get('id')));

		foreach($employes as $employee) {
			$data[] = array(
				'id'   			=> md5($employee->id_certificate_employee),
				'name'  		=> $employee->name,
				'description' 	=> $employee->description,
				'organizer'		=> $employee->organizer,
				'expired'		=> $employee->expired_date,
				'file'			=> $employee->file_upload
			);
		}

		$json = array(
			'TotalRows' => !empty($data) ? sizeof($data) : 0,
			'Rows' => $data
		);

		echo json_encode(array($json));
	}

	public function training()
	{
		$data = array();
		$employes = $this->employee_model->training(array('md5(id_employee)' => $this->input->get('id')));

		foreach($employes as $employee) {
			$data[] = array(
				'id'   			=> md5($employee->id_training_employee),
				'name'  		=> $employee->name,
				'category' 		=> '',
				'organizer'		=> $employee->organizer,
				'expired'		=> $employee->start_time,
				'type'			=> ''
			);
		}

		$json = array(
			'TotalRows' => !empty($data) ? sizeof($data) : 0,
			'Rows' => $data
		);

		echo json_encode(array($json));
	}

	public function education()
	{
		$data = array();
		$employes = $this->employee_model->education(array('md5(id_employee)' => $this->input->get('id')));

		foreach($employes as $employee) {
			$data[] = array(
				'id'   			=> $employee->id_employee_education,
				'id_employee'	=> $employee->id_employee,
				'degre'  		=> $employee->education_degree,
				'institution' 	=> $employee->institute,
				'major'			=> $employee->major,
				'start'			=> $employee->start_year,
				'end'			=> $employee->end_year
			);
		}

		$json = array(
			'TotalRows' => !empty($data) ? sizeof($data) : 0,
			'Rows' => $data
		);

		echo json_encode(array($json));
	}
}
