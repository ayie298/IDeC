<script type="text/javascript">
    $(document).ready(function(){
        $('#jqxTabs').jqxTabs({ width: '60%', height: '215', position: 'top', theme: theme });
		$('#btn_back').click(function () {
			document.location.href="<?php echo site_url('program');?>";
		});

		$('#btn_target').click(function () {
			document.location.href="#target";
		});

		$("#tanggal,#tanggal_end").jqxDateTimeInput({ width: '140px', height: '30px', formatString: 'yyyy-MM-dd', theme: theme});
	});
</script>
<style type="text/css">
.white {
    background: white;
}

</style>
<div id="popup" style="display:none">
	<div id="popup_title">Program Data</div><div id="popup_content">{popup}</div>
</div>
<div class="row-fluid">
   <div class="span12">
	   <h3 class="page-title">
		 Program Data
	   </h3>
   </div>
</div>
<div class="row-fluid">
	<?php $notice = $this->session->flashdata('notice') ?>
	<?php echo !empty($notice) ? '<div class="alert">'.$this->session->flashdata('notice') : '' ?>
</div>
<div style="width:99%;background-color:#DDDDDD;-moz-border-radius:5px;border-radius:5px;padding:2px;border:3px solid #ebebeb;">
    <table width='100%' cellpadding='4' cellspacing='2' border='0' style="border: 1px solid rgb(204,209,205);background: rgb(244,244,244);font-size:14px">
    <tr id="td_loading" style="display:none" height="30">
        <td colspan="3" align="right">Processing data ....</td>
    </tr>
<?php echo form_open() ?>
	<input type="hidden" name="id" value="<?php echo !empty($program) ? $program->id_program : '' ?>" />
    <tr>
        <td colspan="3" style="font-size:20px">Program <?php echo $title ?></td>
    </tr>
    <tr id="td_proses" height="30">
        <td colspan="3" align="right">
				<button class='btn' id='btn_target' type='button'>SET TARGET</button>
				<input class='btn' id='btn_save' type='submit' name="submit" />
				<button class='btn' id='btn_back' type='button'>KEMBALI</button>
		</td>
    </tr>
    <tr>
        <td width='18%'>Program Name</td>
        <td width='1%'>:</td>
        <td class="white"><input type="text" size="20" name="name" value="<?php echo !empty($program) ? $program->name : '' ?>" id="Name" placeholder="Name" style="margin: 0;height: 30px;width:400px"/></td>
    </tr>
    <tr>
        <td width='18%'>Budget</td>
        <td width='1%'>:</td>
        <td class="white"><input type="text" size="20" name="budget" value="<?php echo !empty($program) ? $program->budget : '' ?>" id="Name" placeholder="Budget" style="margin: 0;height: 30px;width:400px"/></td>
    </tr>
   <tr>
        <td width='18%'>Unit</td>
        <td width='1%'>:</td>
        <td class="white">
			<select size="1" class="input" name="unit" id="Category" style="width: 300px;margin: 0;">
				<option>Choose Unit</option>
				<?php foreach($organization as $org) : ?>
					<option value="<?php echo $org->id_organization_item ?>" <?php echo !empty($program) && $program->id_organization_item == $org->id_organization_item ? 'selected' : '' ?>><?php echo $org->org_name ?></option>
				<?php endforeach; ?>
			</select>
		</td>
    </tr>
    <tr>
        <td width='18%'>Research Type</td>
        <td width='1%'>:</td>
        <td class="white">
			<select size="1" class="input" name="type" id="Category" style="width: 300px;margin: 0;">
				<option>Choose Type</option>
				<?php foreach($resType as $type) : ?>
					<option value="<?php echo $type->id_mas_research_type ?>" <?php echo !empty($program) && $type->id_mas_research_type == $program->id_mas_research_type ? 'selected' : '' ?>><?php echo $type->type ?></option>
				<?php endforeach; ?>
			</select>
		</td>
    </tr>
   <tr>
        <td width='18%'>Bagian / Lab</td>
        <td width='1%'>:</td>
        <td class="white">
			<select size="1" class="input" name="lab" id="Category" style="width: 300px;margin: 0;">
				<option>Business & Program Planning</option>
				<option>Performance Management</option>
				<option>Quality Management & Research Synergy</option>
				<option>Innovation & Entrepreneurship</option>
			</select>
		</td>
    </tr>
	<tr>
		<td width='18%'>Description</td>
		<td width='1%'>:</td>
		<td class="white"><input type="text" size="20" name="desc" value="<?php echo !empty($program) ? $program->description : '' ?>" id="Description" placeholder="Description" style="margin: 0;height: 30px;width:100px"/></td>
	</tr>
	<tr>
		<td width='18%'>User</td>
		<td width='1%'>:</td>
		<td class="white"><input type="text" size="20" name="user" value="<?php echo !empty($program) ? $program->user : '' ?>" id="User" placeholder="User" style="margin: 0;height: 30px;"/></td>
	</tr>
	<tr>
		<td width='18%'>Start Date</td>
		<td width='1%'>:</td>
        <td class="white"><div id='tanggal' name="date" value="<?php echo !empty($program) ? $program->start_date : '' ?>"></div></td>
	</tr>
	<tr>
		<td width='18%'>End Date</td>
		<td width='1%'>:</td>
        <td class="white"><div id='tanggal_end' name="date_end" value="<?php echo !empty($program) ? $program->end_date : '' ?>"></div></td>
	</tr>
	<tr>
		<td width='18%'>Output</td>
		<td width='1%'>:</td>
		<td class="white"><input type="text" size="20" name="output" value="<?php echo !empty($program) ? $program->output : '' ?>" id="User" placeholder="User" style="margin: 0;height: 30px;"/></td>
	</tr>
   <tr>
        <td width='18%'>Quartal</td>
        <td width='1%'>:</td>
        <td class="white">
			<select size="1" class="input" name="quartal" id="Year" style="width: 100px;margin: 0;">
				<option value="1" <?php echo !empty($program) && $program->quartal == 1 ? 'selected' : '' ?>>TW I</option>
				<option value="2" <?php echo !empty($program) && $program->quartal == 2 ? 'selected' : '' ?>>TW II</option>
				<option value="3" <?php echo !empty($program) && $program->quartal == 3 ? 'selected' : '' ?>>TW III</option>
				<option value="4" <?php echo !empty($program) && $program->quartal == 4 ? 'selected' : '' ?>>TW IV</option>
			</select>
		</td>
    </tr>
   <tr>
        <td width='18%'>PM</td>
        <td width='1%'>:</td>
		<td class="white"><input type="text" size="20" name="pm" value="<?php echo !empty($program) ? $pm : '' ?>" id="User" placeholder="NIK autocomplete" style="margin: 0;height: 30px;"/></td>
    </tr>
   <tr>
        <td width='18%'>PO</td>
        <td width='1%'>:</td>
		<td class="white"><input type="text" size="20" name="po" id="User" value="<?php echo !empty($program) ? $po : '' ?>" placeholder="NIK autocomplete" style="margin: 0;height: 30px;"/></td>
    </tr>
   <tr>
        <td width='18%'>Primary Program ?</td>
        <td width='1%'>:</td>
        <td class="white"><input type="checkbox" name="prime" value="1" <?php echo !empty($program) && $program->primary_program == 1 ? 'checked' : '' ?> class="input"></td>
    </tr>
 	<tr>
		<td width='18%'>Deliverable</td>
		<td width='1%'>:</td>
		<td class="white"><textarea cols="60" name="deliver" rows="4" style="width: 400px;margin: 0;"><?php echo !empty($program) ? $program->deliverable : '' ?></textarea></td>
	</tr>
 	<tr>
		<td width='18%'>KPI</td>
		<td width='1%'>:</td>
		<td class="white"><textarea cols="60" name="kpi" rows="4" style="width: 400px;margin: 0;"><?php echo !empty($program) ? $program->KPI : '' ?></textarea></td>
	</tr>
 	<tr>
		<td width='18%'>Implementation Strategy</td>
		<td width='1%'>:</td>
		<td class="white"><textarea cols="60" name="implement" rows="4" style="width: 400px;margin: 0;"><?php echo !empty($program) ? $program->implementation_strategy : '' ?></textarea></td>
	</tr>
 	<tr>
		<td width='18%'>Strategic Initiative</td>
		<td width='1%'>:</td>
		<td class="white"><textarea cols="60" name="strategic" rows="4" style="width: 400px;margin: 0;"><?php echo !empty($program) ? $program->strategic_initative : '' ?></textarea></td>
	</tr>
    <tr>
        <td width='18%'>Status</td>
        <td width='1%'>:</td>
        <td class="white">
			<select size="1" class="input" name="status" id="Status" style="width: 100px;margin: 0;">
				<?php foreach($status as $stat) : ?>
					<option value="<?php echo $stat->id_mas_project_status ?>" <?php echo !empty($program) && $stat->id_mas_project_status == $program->id_mas_project_status ? 'selected' : '' ?>><?php echo $stat->status ?></option>
				<?php endforeach; ?>
			</select>
		</td>
    </tr>
</form>
   <tr>
        <td colspan="3">
		<div style="padding-top:10px;padding-bottom:10px;"><a name="target">Program Target</a></div>

			<div id="jqxTabs">
				<ul>
					<li>TW I</li>
					<li>TW II</li>
					<li>TW III</li>
					<li>TW IV</li>
				</ul>
				<div style="padding: 10px;">
				{tw}
				</div>
				<div style="padding: 10px;">
				{tw}
				</div>
				<div style="padding: 10px;">
				{tw}
				</div>
				<div style="padding: 10px;">
				{tw}
				</div>
			</div>		
		</td>
    </tr>
    </table>
</div>
