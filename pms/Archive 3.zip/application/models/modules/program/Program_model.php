<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Program_model extends CI_Model {

	public $table = 'program';

	public function __construct()
	{
		parent::__construct();
	}

	public function find($where = array())
	{
		if(!empty($where)) {
			$this->db->where($where);
		}

		return $this->getProgram('row');
	}

	public function findAll($where = array(), $whereOR = array(), $whereLike = array())
	{
		if(!empty($where)) {
			$this->db->where($where);
		}

		if(!empty($whereOR)) {
			$queryOr = "";

			foreach($whereOR as $key => $value) {
				if(is_array($whereOR[$key])) {
					for($j=0;$j<sizeof($whereOR[$key]);$j++) {
						$queryOr .= $key . ' = ' . $whereOR[$key][$j] . ' OR ';
					}
				}
			}

			$this->db->where('(' . substr($queryOr, 0, strlen($queryOr)-3) . ')');
		}

		if(!empty($whereLike)) {
			$this->db->like($whereLike);
		}

		return $this->getProgram();
	}

	public function getProgram($type = 'result')
	{
		$this->db->join('organization_item as org', 'org.id_organization_item = program.id_organization_item');

		return $this->db->get($this->table)->{$type}();
	}

	public function getAutoIncrement()
	{
		$this->db->order_by('id_program',' DESC');

		$num = $this->getProgram('row');
		$num = $num->id_program+1;

		return $num;
	}
}