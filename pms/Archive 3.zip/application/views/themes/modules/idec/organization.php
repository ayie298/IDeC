<script>
	$(function(){
       $("#bar_profile").click();
       
    }); 
	
	function poping(id){
		var theme = "arctic";
		$("#popup").jqxWindow({
			theme: theme, resizable: false,
			width: 700,
			height: 450,
			isModal: true, autoOpen: false, modalOpacity: 0.2
		});
		$("#popup").jqxWindow('open');

	}
</script>
<div id="popup" style="display:none">
	<div id="popup_title">Organization Structure</div>
	<div id="popup_content">
		<div style="padding:5px;border:2px solid white;width:98%;position:relative;float:left">
			<table cellpadding="4" cellspacing="2" width="100%" style="font-size:12px;border:1px solid #CCC;color:#000">
				<tr style="background:#DDD;height:50px">
					<td colspan="2" align="center">BIDANG INNOVATION MANAGEMENT</td>
				</tr>
				<tr>
					<td>SENIOR MANAGER INNOVATION MANAGEMENT</td>
					<td>DINOOR SUSATIJO</td>
				</tr>
				<tr>
					<td>&nbsp;&nbsp;&nbsp;&nbsp;RESEARCHER BROADBAND COMMUNICATION SERVICE</td>
					<td>HERU RAMDHANI</td>
				</tr>
				<tr>
					<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;MANAGER BUSINESS & PROGRAM PLANNING</td>
					<td>PRA SETIAWAN</td>
				</tr>
				<tr>
					<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;OFFICER 1 STRATEGIC PLANNING</td>
					<td>YOVITA MISRIGA, ST</td>
				</tr>
				<tr>
					<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;OFFICER 1 BUDGETING, PROGRAM PLANNING & MONITORING</td>
					<td>LAKSONO SUGENG SANTOSO</td>
				</tr>
				<tr>
					<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;OFFICER 1 INNOVATION PROGRAM PLANNING & MONITORING</td>
					<td>SENDYLENVI REGIA</td>
				</tr>
				<tr>
					<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;OFFICER 2 INNOVATION PROGRAM PLANNING & MONITORING</td>
					<td>RANI GUSTIANI</td>
				</tr>
				<tr>
					<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;MANAGER PERFORMANCE MANAGEMENT</td>
					<td>AHMAD ARIF RAHMAN</td>
				</tr>
				<tr>
					<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;OFFICER 1 PERFORMANCE EVALUATION & ANALYSIS</td>
					<td>CARLI</td>
				</tr>
				<tr>
					<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;OFFICER 1 BUSINESS PROCESS AUDIT</td>
					<td>EDDY YUNIARTO</td>
				</tr>
				<tr>
					<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;OFFICER 1 PERFORMANCE MEASUREMENT & ANALYSIS</td>
					<td>ABDUL MUIS</td>
				</tr>
				<tr>
					<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;MANAGER INNOVATION & ENTERPRENEURSHIP</td>
					<td>JOHANES ADI PURNAMA PUTRA</td>
				</tr>
			</table>
		</div>
	</div>
</div>
<div class="row-fluid">
   <div class="span12">
	   <h3 class="page-title">
		 Organization Structure 
	   </h3>
   </div>
</div>
<iframe id="preview-frame" src="<?php echo base_url();?>idec/organization/tree" name="preview-frame" frameborder="0" noresize="noresize" height="450" width="100%"></iframe>