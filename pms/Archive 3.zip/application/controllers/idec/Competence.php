<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Competence extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		
		$this->load->library('files');
		$this->load->library('user');

		$this->load->model('modules/users/user_model');
		$this->load->model('modules/employee/employee_model');
		$this->load->model('idec_model');

		$this->template->set_template('login');
	}

	public function add($id = "")
	{
		if($_POST) {
			$validation = array(
				array(
					'field' => 'competence[]',
					'label' => 'Competence',
					'rules' => 'required'
				),
			);

			$this->form_validation->set_rules($validation);

			if($this->form_validation->run() == TRUE) {
				$competence = $this->input->post('competence');

				$data['id_employee']		= $this->input->post('id');
				$data['id_mas_competence']  = $competence;

				$this->db->insert('competence_employee', $data);

				$this->session->set_flashdata('notice', 'Competence has been added');
			} else {
				$this->session->set_flashdata('notice', validation_errors());
			}

			redirect('idec/employee/edit/' . md5($this->input->post('id')));

			return FALSE;
		}

		$data['title'] 		=  'Add';
		$data['competence']	= $this->employee_model->getCompetence();
		$data['id_employee'] = $id;

		$this->load->view(MODULE_VIEW_PATH.'employee/employee_competence_add', $data);
	}

	public function delete($id_emp, $id)
	{
		$this->db->where('id_competence_employee', $id);
		$this->db->delete('competence_employee');

		$this->session->set_flashdata('notice', 'Competence deleted');

		redirect('idec/employee/edit/' . md5($id_emp));
	}
}
