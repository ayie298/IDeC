<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Education extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		
		$this->load->library('files');
		$this->load->library('user');

		$this->load->model('modules/users/user_model');
		$this->load->model('idec_model');

		$this->template->set_template('login');
	}

	public function add($id = '')
	{
		if($_POST) {
			$validation = array(
				array(
					'field' => 'degree',
					'label' => 'Degree',
					'rules' => 'required'
				),
				array(
					'field' => 'institute',
					'label' => 'Institute',
					'rules' => 'required'
				),
				array(
					'field' => 'major',
					'label' => 'Major',
					'rules' => 'required'
				),
				array(
					'field' => 'start_year',
					'label' => 'Start Year',
					'rules' => 'required'
				),
				array(
					'field' => 'end_year',
					'label' => 'End Year',
					'rules' => 'required'
				),
			);

			$this->form_validation->set_rules($validation);

			if($this->form_validation->run() == TRUE) {
				$data['education_degree'] 	= $this->input->post('degree');
				$data['institute']			= $this->input->post('institute');
				$data['major']				= $this->input->post('major');
				$data['start_year']			= $this->input->post('start_year');
				$data['end_year']			= $this->input->post('end_year');
				$data['id_employee']		= $this->input->post('id');

				$this->db->insert('employee_education', $data);

				$this->session->set_flashdata('notice', 'Education has been added');
			} else {
				$this->session->set_flashdata('notice', validation_errors());
			}

			redirect('idec/employee/edit/' . md5($this->input->post('id')));

			return FALSE;
		}

		$data['id_employee'] = $id;

		$this->load->view(MODULE_VIEW_PATH.'employee/employee_education_add', $data);
	}

	public function delete($id_emp, $id)
	{
		$this->db->where('id_employee_education', $id);
		$this->db->delete('employee_education');

		$this->session->set_flashdata('notice', 'Education deleted');

		redirect('idec/employee/edit/' . md5($id_emp));
	}
}
