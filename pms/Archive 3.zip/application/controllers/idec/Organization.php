<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Organization extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		
		$this->load->library('files');
		$this->load->library('user');

		$this->load->model('modules/users/user_model');
		$this->load->model('modules/employee/employee_model');
		$this->load->model('idec_model');
	}

	public function index()
	{
		$this->template->write_view('content', MODULE_VIEW_PATH.'idec/organization');
		$this->template->render();
	}

	public function tree()
	{
		$data['organization'] = $this->employee_model->organization(array('row' => 1));

		$this->load->view(MODULE_VIEW_PATH.'idec/chart', $data);
	}
}
