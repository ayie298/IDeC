<script type="text/javascript">
    $(document).ready(function(){
        $('#jqxTabs').jqxTabs({ width: '60%', height: '130', position: 'top', theme: theme });
		$('#btn_back').click(function () {
			document.location.href="<?php echo base_url();?>idec_pms/program";
		});

		$('#btn_target').click(function () {
			document.location.href="<?php echo base_url();?>idec_pms/program_new";
		});

	});
</script>
<style type="text/css">
.white {
    background: white;
	font-size:14px;
}

</style>
<div id="popup" style="display:none">
	<div id="popup_title">Program Data</div><div id="popup_content">{popup}</div>
</div>
<div class="row-fluid">
   <div class="span12">
	   <h3 class="page-title">
		 Program Data
	   </h3>
   </div>
</div>
<div style="width:99%;background-color:#DDDDDD;-moz-border-radius:5px;border-radius:5px;padding:2px;border:3px solid #ebebeb;">
    <table width='100%' cellpadding='4' cellspacing='2' border='0' style="border: 1px solid rgb(204,209,205);background: rgb(244,244,244);">
    <tr>
        <td colspan="2" style="font-size:20px">Program Detail</td>
    </tr>
    <tr id="td_proses" height="30">
        <td colspan="2" align="right">
			<?php if($this->session->userdata('level')!="researcher"){?><button class='btn' id='btn_target' type='button'>EDIT PROGRAM</button><?php }?>
			<button class='btn' id='btn_back' type='button'>KEMBALI</button>
		</td>
    </tr>
    <tr valign="top">
        <td width="50%">
		<table cellpadding="4" cellspacing="4" width="95%" style="font-size:14px">
			<tr valign="top">
				<td width='28%'>Program Name</td>
				<td width='1%'>:</td>
				<td class="white">Seleksi Indigo Incubator</td>
			</tr>
		   <tr valign="top">
				<td width='28%'>Unit</td>
				<td width='1%'>:</td>
				<td class="white">Innovation Management</td>
			</tr>
		   <tr valign="top">
				<td width='28%'>Bagian / Lab</td>
				<td width='1%'>:</td>
				<td class="white">Innovation & Entrepreneurship</td>
			</tr>
			<tr valign="top">
				<td width='28%'>Description</td>
				<td width='1%'>:</td>
				<td class="white">Inkubasi</td>
			</tr>
			<tr valign="top">
				<td width='28%'>User</td>
				<td width='1%'>:</td>
				<td class="white">RDC</td>
			</tr>
			<tr valign="top">
				<td width='28%'>Start Date</td>
				<td width='1%'>:</td>
				<td class="white">1 Jan 2014</td>
			</tr>
			<tr valign="top">
				<td width='28%'>End Date</td>
				<td width='1%'>:</td>
				<td class="white">31 May 2014</td>
			</tr>
		   <tr valign="top">
				<td width='28%'>Quartal</td>
				<td width='1%'>:</td>
				<td class="white">TW II</td>
			</tr>
		   <tr valign="top">
				<td width='28%'>PM</td>
				<td width='1%'>:</td>
				<td class="white">&nbsp;</td>
			</tr>
		   <tr valign="top">
				<td width='28%'>PO</td>
				<td width='1%'>:</td>
				<td class="white">Johanes Adi Purnama Putra</td>
			</tr>
		   <tr valign="top">
				<td width='28%'>Primary Program ?</td>
				<td width='1%'>:</td>
				<td class="white">Ya</td>
			</tr>
		</table>
		</td>
        <td width="50%">
		<table cellpadding="4" cellspacing="4" width="95%" style="font-size:14px">
			<tr valign="top">
				<td width='28%'>Deliverable</td>
				<td width='1%'>:</td>
				<td class="white"># of incubation proposal<br># of Incubated Start Ups<br># of Validated Products<br># of Validated Business Model</td>
			</tr>
			<tr valign="top">
				<td width='28%'>KPI</td>
				<td width='1%'>:</td>
				<td class="white">400 of incubation proposals<br>- Incubated StartUp : 30  (BDV=20, JDV=10)<br>- Validated Products : 20<br>- Validated Business Model : 10</td>
			</tr>
			<tr valign="top">
				<td width='28%'>Implementation Strategy</td>
				<td width='1%'>:</td>
				<td class="white">- Roadshow (socialization),<br>- Partnering with MIKTI (Running the Incubation)<br>- Partnering with Global Incubators (Global Mentor)</td>
			</tr>
			<tr valign="top">
				<td width='28%'>Strategic Initiative</td>
				<td width='1%'>:</td>
				<td class="white">SI-1 Center of Excellent</td>
			</tr>
			<tr valign="top">
				<td width='28%'>Status</td>
				<td width='1%'>:</td>
				<td class="white">On Going</td>
			</tr>
 		</table>
		</td>
    </tr>
	<tr valign="top">
        <td colspan="2">
		<div style="padding-top:10px;padding-bottom:10px;">Program Target</div>

			<div id="jqxTabs">
				<ul>
					<li>TW I</li>
					<li>TW II</li>
					<li>TW III</li>
					<li>TW IV</li>
				</ul>
				<div style="padding: 10px;">
				{tw}
				</div>
				<div style="padding: 10px;">
				{tw}
				</div>
				<div style="padding: 10px;">
				{tw}
				</div>
				<div style="padding: 10px;">
				{tw}
				</div>
			</div>		
		</td>
    </tr>
    </table>
</div>
