<link  href="<?php echo base_url(); ?>plugins/js/jHorizontalTree/css/style.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url(); ?>plugins/js/jHorizontalTree/js/jquery-1.8.1.min.js"></script>
<script src="<?php echo base_url(); ?>plugins/js/jHorizontalTree/js/jquery-ui.js"></script>
<script src="<?php echo base_url(); ?>plugins/js/jHorizontalTree/js/jquery.tree.js"></script>
<script>
$(document).ready(function() {
	$('.tree').tree_structure({
		'add_option': false,
		'edit_option': false,
		'delete_option': false,
		'confirm_before_delete' : true,
		'animate_option': [true, 5],
		'fullwidth_option': false,
		'align_option': 'center',
		'draggable_option': false
	});

	$(".pop").click(function(){
		parent.poping(1);
	});
});

</script>
<div class="overflow" style="width:1450px;margin:0px">
	<div>
		<ul class="tree">
			<?php foreach($organization as $org) : ?>
			<li>
				<?php if($org->row == 1) : ?>
					<div style="width:200px;min-height:60px" class="pop"><img src="<?php echo base_url(); ?>media/images/profile.jpeg" height="60"><br><?php echo $org->org_name ?></div>
				<?php endif; ?>
				<ul class="tree">
					<?php $tree2 = $this->employee_model->organization(array('id_organization_item_parent' => $org->id_organization_item)); ?>
					<?php foreach($tree2 as $tree) : ?>
					<li>
						<div style="width:200px;min-height:60px" class="pop"><img src="<?php echo base_url(); ?>media/images/profile.jpeg" height="60"><br><?php echo $tree->org_name ?></div>
						<ul>
							<?php $tree3 = $this->employee_model->organization(array('id_organization_item_parent' => $tree->id_organization_item)); ?>
							<?php foreach($tree3 as $tree3) : ?>
							<li>
								<div style="width:100px;min-height:45px" class="pop"><img src="<?php echo base_url(); ?>media/images/profile.jpeg" height="60"><br><?php echo $tree3->org_name ?></div>
							</li>
							<?php endforeach; ?>
						</ul>
					</li>
					<?php endforeach; ?>
				</ul>
			</li>
			<?php endforeach; ?>
		</ul>
	</div>
</div>
<br><br>