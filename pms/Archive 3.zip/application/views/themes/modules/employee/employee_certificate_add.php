<script type="text/javascript">
    $(document).ready(function(){
        $("#tanggal2").jqxDateTimeInput({ width: '140px', height: '30px', formatString: 'yyyy-MM-dd', theme: theme});
	});
</script>
<div style="width:99%;background-color:#DDDDDD;-moz-border-radius:5px;border-radius:5px;padding:2px;border:3px solid #ebebeb;">
    <table width='100%' cellpadding='4' cellspacing='2' border='0' style="border: 1px solid rgb(204,209,205);background: rgb(244,244,244);">
    <tr>
        <td colspan="3" style="font-size:20px">Add / Edit Certificate</td>
    </tr>
    <tr id="td_proses" height="30">
        <td colspan="3" align="right">
			<button class='btn' id='btn_save' type='button'>SAVE</button>
		</td>
    </tr>
    <tr>
        <td width='18%'>Name</td>
        <td width='1%'>:</td>
        <td class="white"><input type="text" size="20" name="Name" id="Name" placeholder="Name" style="margin: 0;height: 30px;"/></td>
    </tr>
    <tr>
        <td width='18%'>Category</td>
        <td width='1%'>:</td>
        <td class="white">
			<select size="1" class="input" name="Category" id="Category" style="width: 300px;margin: 0;">
				<option>Telecomunication</option>
				<option>Telecomunication</option>
			</select>
		</td>
    </tr>
    <tr>
        <td width='18%'>Expired Date</td>
        <td width='1%'>:</td>
        <td class="white"><div id='tanggal2'></div></td>
    </tr>
    <tr>
        <td width='18%'>Orgainzer</td>
        <td width='1%'>:</td>
        <td class="white"><input type="text" size="25" name="Orgainzer" id="Orgainzer" placeholder="Orgainzer" style="margin: 0;height: 30px;"/></td>
    </tr>
    </table>
</div>
