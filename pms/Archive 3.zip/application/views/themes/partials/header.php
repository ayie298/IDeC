<ul class='menu-1'>
                              <li id='list_1'><a href="<?php echo site_url('idec') ?>"><i class='icon-dashboard'></i>&nbsp; <span>Home</span></a>
                                <ul class='menu-1'>
                                  <li id='list_29'><a href="<?php echo site_url('idec/organization') ?>"><i class='icon-sitemap'></i>&nbsp; <span>Organization Structure</span></a></li>
                                  <li id='list_30'><a href="<?php echo site_url('idec/anual') ?>"><i class='icon-tasks'></i>&nbsp; <span>Annual Data</span></a></li>
                                  <li id='list_31'><a href="<?php echo site_url('idec/employee') ?>"><i class='icon-smile'></i>&nbsp; <span>Employee</span></a></li>
                                </ul>
                              </li>
                              <li id='list_1'>
                                <a href="">
                                  <i class='icon-magic'></i>&nbsp; <span>PMS</span>
                                </a>
                                <ul class='menu-1'>
                                  <li id='list_9'><a href="<?php echo site_url('program') ?>"><i class='icon-book'></i>&nbsp; <span>Program</span></a></li>
                                  <!--<li id='list_8'><a href="http://idec.byethost4.com/idec_pms/performance.hrmis"><i class='icon-screenshot'></i>&nbsp; <span>Performance</span></a></li>
                                  <li id='list_10'><a href="http://idec.byethost4.com/idec_pms/review.hrmis"><i class='icon-check'></i>&nbsp; <span>Management Review</span></a></li>-->
                                </ul>
                              </li>
                              <li id="3">
                                <a href="#">
                                  <i class='icon-beaker'></i>&nbsp; <span>Researcher</span>
                                </a>
                                  <ul class='menu-1'>
                                    <li id='list_32'><a href="<?php echo site_url('researcher') ?>"><i class='icon-group'></i>&nbsp; <span>Data Researcher</span></a></li>
                                    <li id='list_34'><a href="<?php echo site_url('researcher/project'); ?>"><i class='icon-flag-checkered'></i>&nbsp; <span>Project Researcher</span></a></li>
                                    <!--<li id='list_33'><a href="http://idec.byethost4.com/idec_rms/researcher_map.hrmis"><i class='icon-globe'></i>&nbsp; <span>BKO Researcher</span></a></li>
                                    <li id='list_57'><a href="http://idec.byethost4.com/idec_rms/projectbidang.hrmis"><i class='icon-tags'></i>&nbsp; <span>Project Bidang</span></a></li>-->
                                  </ul>
                              </li>
                              <li id='list_1'><a href="<?php echo site_url('idec/logout') ?>"><i class='icon-dashboard'></i>&nbsp; <span>Logout</span></a></li>
                            </ul>