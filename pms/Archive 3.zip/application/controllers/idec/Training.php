<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Training extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		
		$this->load->library('files');
		$this->load->library('user');

		$this->load->model('modules/users/user_model');
		$this->load->model('idec_model');

		$this->template->set_template('login');
	}

	public function add()
	{
		$this->load->view(MODULE_VIEW_PATH.'employee/employee_training_add');
	}
}
