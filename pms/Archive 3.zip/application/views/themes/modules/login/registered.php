<div style="width:99%;background-color:#F6F6F6;-moz-border-radius:5px;border-radius:5px;padding:2px;border:3px solid #F9F9F9;height:40px">
	<table width='100%' cellpadding=0 cellspacing=0 height='100%'>
		<tr valign="middle">
			<td style='background:#FFFFFF;-moz-border-radius:5px 0px 0px 5px;border-radius:5px 0px 0px 5px;padding-left:5px;font-size:15px;color:#585858;font-weight:bold' width='20%'>
				. {title}
			</td>
			<td style='background:#EDEDED;-moz-border-radius:0px 5px 5px 0px;border-radius:0px 5px 5px 0px;text-align:right;padding-right:20px'>
			</td>
		</tr>
	</table>
</div>
<div style="width:99%;background-color:#DDDDDD;-moz-border-radius:5px;border-radius:5px;padding:2px;border:3px solid #ebebeb;min-height:390px">
	<br /><br /><br /><br /><br /><br />
	<table border="0" cellpadding="20" cellspacing="2" align="center">
		<tr>
			<td class="panel">
				<table border="0" cellpadding="10" cellspacing="2">
					<tr>
						<td>Terimakasih <b>{nama}</b>, anda telah mengajukan pendaftaran untuk perusahaan <b>{nama_perusahaan}</b></td>
					</tr>
					<tr>
						<td>Username anda <b>{username}</b> dengan email <b>{email}</b></b></td>
					</tr>
					<tr>
						<td>Petugas kami akan menghubungi anda melalui email jika account anda telah aktif.</b></td>
					</tr>
				</table>

			</td>
		</tr>
	</table>
</div>
