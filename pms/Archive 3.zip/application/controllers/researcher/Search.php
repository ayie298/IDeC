<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Search extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		
		$this->load->library('files');
		$this->load->library('user');

		$this->load->model('modules/users/user_model');
		$this->load->model('modules/employee/employee_model');
		$this->load->model('modules/researcher/researcher_model');
		$this->load->model('idec_model');
	}

	public function index()
	{
		$data['organization'] 	= $this->employee_model->organization(array('level' => 'unit'));
		$data['competence']		= $this->employee_model->getCompetence();

		$this->template->write_view('content', MODULE_VIEW_PATH.'researcher/researcher_search', $data);
		$this->template->render();
	}

	public function json_output()
	{
		$position 	 = $this->employee_model->position(array('position' => 'RESEARCHER'));
		$id_position = $position[0]->id_mas_employee_position;
		$filterOR 	 = array();
		$filterLike  = array();

		$filter['employee.id_mas_employee_position'] = $id_position;

		if($this->session->userdata('unit') != "") {
			$filter['employee.id_organization_item'] = $this->session->userdata('unit');
		}

		if($this->session->userdata('comptSearch') != "") {
			$competence = $this->session->userdata('comptSearch');

			for($i=0;$i<sizeof($competence);$i++) {
				$search = $this->idec_model->findMaster('mas_competence', array('where' => 'name = "' . $competence[$i] .'"'), 'row');

				$filterOR['competence_employee.id_mas_competence'][] = $search->id_mas_competence;
			}
		}

		if($this->session->userdata('nikSearch') != "") {
			$filter['employee.nik'] = $this->session->userdata('nikSearch');
		}

		if($this->session->userdata('trainSearch') != "") {
			$search = $this->idec_model->findMaster('training', array('like' => 'name,' . $this->session->userdata('trainSearch')));

			foreach($search as $s) {
				$filterOR['training_employee.id_training'][] = $s->id_training;
			}
		}

		if($this->session->userdata('nameSearch') != "") {
			$filterLike['employee.name'] = $this->session->userdata('nameSearch');
		}

		if($this->session->userdata('sertSearch') != "") {
			$filter['employee.id_organization_item'] = $this->session->userdata('sertSearch');
		}

		$employee 	 = $this->researcher_model->findAll($filter, $filterOR, $filterLike);
		$data 		 = array();

		foreach($employee as $employee) {
			$data[] = array(
				'id'   		=> md5($employee->id_employee),
				'nik'  		=> $employee->nik,
				'nama' 		=> $employee->name,
				'posisi'	=> $employee->position,
				'project'	=> 0,
				'activity'	=> '',
				'close'		=> '',
				'unit'		=> ''
			);
		}

		$json = array(
			'TotalRows' => sizeof($data),
			'Rows' => $data
		);

		echo json_encode(array($json));

		$this->session->unset_userdata('unit');
		$this->session->unset_userdata('comptSearch');
		$this->session->unset_userdata('nameSearch');
		$this->session->unset_userdata('nikSearch');
		$this->session->unset_userdata('sertSearch');
		$this->session->unset_userdata('trainSearch');
	}
}
