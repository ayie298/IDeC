<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		
		$this->load->library('files');
		$this->load->library('user');

		$this->load->model('modules/users/user_model');
		$this->load->model('modules/employee/employee_model');
		$this->load->model('idec_model');
	}

	public function index()
	{
		if($_POST) {
			$this->session->set_userdata('unit', $this->input->post('unit'));
			$this->session->set_userdata('comptSearch', $this->input->post('competence'));
			$this->session->set_userdata('nameSearch', $this->input->post('name'));
			$this->session->set_userdata('nikSearch', $this->input->post('nik'));

			redirect('researcher/search/');
		}

		$data['organization'] 	= $this->employee_model->organization(array('level' => 'unit'));
		$data['competence']		= $this->employee_model->getCompetence();

		if($this->user->row()->level_name == "researcher"){
			$this->researcher_detail();
		}else{
			$this->template->write_view('content', MODULE_VIEW_PATH.'researcher/researcher', $data);
		}

		$this->template->render();
	}
}
