<table width='100%' cellpadding='4' cellspacing='2' border='0' style="border: 1px solid rgb(204,209,205);">
	<tr>
		<td width='20%'>Metric</td>
		<td width='20%'>Value</td>
		<td width='40%'>Target Detail</td>
	</tr>
	<tr>
		<td>Quantity</td>
		<td>50</td>
		<td>Rata rata jumlah user per bulan</td>
	</tr>
</table>
<br>
