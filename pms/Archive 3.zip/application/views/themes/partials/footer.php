<!-- BEGIN FOOTER -->
   <div id="footer">   
        <br/>
        <img src="<?php echo base_url();?>public/themes/idec/front/images/bbro_white.png" style="max-width:80px !important;height:auto;"/>
        <br/>2014 &copy; TELKOM Innovation & Design Centre (IDeC).
        <br/>
   </div>
   <!-- END FOOTER -->

    <script type="text/javascript" language="javascript" src="<?php echo base_url(); ?>plugins/js/assets/jquery-slimscroll/jquery-ui-1.9.2.custom.min.js"></script>
    <script type="text/javascript" language="javascript" src="<?php echo base_url(); ?>plugins/js/assets/jquery-slimscroll/jquery.slimscroll.min.js"></script>
    <script type="text/javascript" language="javascript" src="<?php echo base_url(); ?>plugins/js/assets/fullcalendar/fullcalendar/fullcalendar.min.js"></script>
    <script type="text/javascript" language="javascript" src="<?php echo base_url(); ?>plugins/js/assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
    <script type="text/javascript" language="javascript" src="<?php echo base_url(); ?>plugins/js/assets/bootstrap/js/bootstrap.min.js"></script>
    <!--<script type="text/javascript" language="javascript" src="<?php echo base_url(); ?>plugins/js/metro/common-scripts.js"></script>-->
    <script type="text/javascript" language="javascript" src="<?php echo base_url(); ?>plugins/js/metro/jquery.nicescroll.js"></script>
    
<!-- START CHART -->    
    <script type="text/javascript" language="javascript" src="<?php echo base_url(); ?>plugins/js/jquery.sparkline.js"></script>
    <script type="text/javascript" language="javascript" src="<?php echo base_url(); ?>plugins/js/assets/chart-master/Chart.js"></script>
    
    <script type="text/javascript" language="javascript" src="<?php echo base_url(); ?>plugins/js/easy-pie-chart.js"></script>
    <script type="text/javascript" language="javascript" src="<?php echo base_url(); ?>plugins/js/sparkline-chart.js"></script> 
<!-- <script type="text/javascript" language="javascript" src="<?php echo base_url(); ?>plugins/js/chartjs.js"></script>-->
<!-- END CHART -->
    <script type="text/javascript" language="javascript" src="<?php echo base_url()?>plugins/js/jquery/jqwidgets/jqxcore.js"></script>
    <script type="text/javascript" language="javascript" src="<?php echo base_url()?>plugins/js/jquery/jqwidgets/jqxdata.js"></script>
    <script type="text/javascript" language="javascript" src="<?php echo base_url()?>plugins/js/jquery/jqwidgets/jqxbuttons.js"></script>
    <script type="text/javascript" language="javascript" src="<?php echo base_url()?>plugins/js/jquery/jqwidgets/jqxinput.js"></script>
    <script type="text/javascript" language="javascript" src="<?php echo base_url()?>plugins/js/jquery/jqwidgets/jqxtabs.js"></script>
    <script type="text/javascript" language="javascript" src="<?php echo base_url()?>plugins/js/jquery/jqwidgets/jqxbuttons.js"></script>
    <script type="text/javascript" language="javascript" src="<?php echo base_url()?>plugins/js/jquery/jqwidgets/jqxscrollbar.js"></script>
    <script type="text/javascript" language="javascript" src="<?php echo base_url()?>plugins/js/jquery/jqwidgets/jqxlistbox.js"></script>
    <script type="text/javascript" language="javascript" src="<?php echo base_url()?>plugins/js/jquery/jqwidgets/jqxdropdownlist.js"></script>
    <script type="text/javascript" language="javascript" src="<?php echo base_url()?>plugins/js/jquery/jqwidgets/jqxwindow.js"></script>
    <script type="text/javascript" language="javascript" src="<?php echo base_url()?>plugins/js/jquery/jqwidgets/jqxmenu.js"></script>
    <script type="text/javascript" language="javascript" src="<?php echo base_url()?>plugins/js/jquery/jqwidgets/jqxgrid.js"></script>
    <script type="text/javascript" language="javascript" src="<?php echo base_url()?>plugins/js/jquery/jqwidgets/jqxgrid.selection.js"></script>    
    <script type="text/javascript" language="javascript" src="<?php echo base_url()?>plugins/js/jquery/jqwidgets/jqxgrid.edit.js"></script>
    <script type="text/javascript" language="javascript" src="<?php echo base_url()?>plugins/js/jquery/jqwidgets/jqxgrid.filter.js"></script>   
    <script type="text/javascript" language="javascript" src="<?php echo base_url()?>plugins/js/jquery/jqwidgets/jqxgrid.sort.js"></script>     
    <script type="text/javascript" language="javascript" src="<?php echo base_url()?>plugins/js/jquery/jqwidgets/jqxgrid.pager.js"></script>        
    <script type="text/javascript" language="javascript" src="<?php echo base_url()?>plugins/js/jquery/jqwidgets/jqxgrid.columnsresize.js"></script>        
    <script type="text/javascript" language="javascript" src="<?php echo base_url()?>plugins/js/jquery/jqwidgets/jqxpanel.js"></script>
    <script type="text/javascript" language="javascript" src="<?php echo base_url()?>plugins/js/jquery/jqwidgets/jqxcalendar.js"></script>
    <script type="text/javascript" language="javascript" src="<?php echo base_url()?>plugins/js/jquery/jqwidgets/jqxdatetimeinput.js"></script>
    <script type="text/javascript" language="javascript" src="<?php echo base_url()?>plugins/js/jquery/jqwidgets/jqxcheckbox.js"></script>
    <script type="text/javascript" language="javascript" src="<?php echo base_url()?>plugins/js/jquery/jqwidgets/globalization/globalize.js"></script>
    <script type="text/javascript" language="javascript" src="<?php echo base_url()?>plugins/js/jquery/jqwidgets/jqxdata.js"></script>  
    <script type="text/javascript" language="javascript" src="<?php echo base_url()?>plugins/js/jquery/jqwidgets/jqxlistbox.js"></script>
    <script type="text/javascript" language="javascript" src="<?php echo base_url()?>plugins/js/jquery/jqwidgets/jqxnavigationbar.js"></script>
    <script type="text/javascript" language="javascript" src="<?php echo base_url()?>plugins/js/jquery/jqwidgets/jqxchart.js"></script>
    <script type="text/javascript" language="javascript" src="<?php echo base_url()?>plugins/js/jquery/jqwidgets/jqxtree.js"></script>
    <script type="text/javascript" language="javascript" src="<?php echo base_url()?>plugins/js/jquery/jqwidgets/jqxdocking.js"></script>
    <script type="text/javascript" language="javascript" src="<?php echo base_url()?>plugins/js/jquery/jqwidgets/jqxdata.export.js"></script> 
    <script type="text/javascript" language="javascript" src="<?php echo base_url()?>plugins/js/jquery/jqwidgets/jqxgrid.export.js"></script> 
    <script type="text/javascript" language="javascript" src="<?php echo base_url()?>plugins/js/jquery/jqwidgets/jqxnumberinput.js"></script>
    <script type="text/javascript" language="javascript" src="<?php echo base_url()?>plugins/js/jquery/jqwidgets/jqxmaskedinput.js"></script>
    <script type="text/javascript" language="javascript" src="<?php echo base_url()?>plugins/js/jquery/jqwidgets/jqxdatatable.js"></script>
    <script type="text/javascript" language="javascript" src="<?php echo base_url()?>plugins/js/jquery/jqwidgets/jqxtreegrid.js"></script>
    <script type="text/javascript">
        $(document).ready(function(){
            //setInterval("load_count_msg();",10000);
            $('#main-content').css({
                'margin-left': '0px'
            });
            $('#sidebar').css({
                'margin-left': '-210px',
                'margin-top':'20px'
            });
        });
        
        var theme = "arctic";
        
        function load_count_msg(){
        $.ajax({
          type: "GET",
          url: "<?php echo base_url(); ?>index.php/msg/load_count_msg",
          success: function(response){
               $("#header_inbox_bar").html(response);
            }
          });
        }
    </script>
</body>
</html>f